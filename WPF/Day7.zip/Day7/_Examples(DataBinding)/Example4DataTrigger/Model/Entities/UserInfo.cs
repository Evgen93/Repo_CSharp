﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4DataTrigger.Model.Entities
{
	public class UserInfo
	{
		public string Login { get; set; }
		public string Email { get; set; }
		public string Password { get; set; }

		public RoleType RoleType { get; set; }
	}

	public enum RoleType
	{
		Admin,
		User,
		Manager
	}
}
