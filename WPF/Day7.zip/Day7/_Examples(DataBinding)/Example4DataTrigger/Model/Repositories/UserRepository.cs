﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Example4DataTrigger.Model.Entities;

namespace Example4DataTrigger.Model.Repositories
{
	public class UserRepository
	{
		private ObservableCollection<UserInfo> _users;

		public UserRepository()
		{
			_users = new ObservableCollection<UserInfo>()
			{
				new UserInfo(){Login = "Manager", Email = "Manager@mail.by", Password = "12345", RoleType = RoleType.Manager},
				new UserInfo(){Login = "Admin", Email = "Admin@mail.by", Password = "284678", RoleType = RoleType.Admin},
				new UserInfo(){Login = "User", Email = "User@mail.by", Password = "11111", RoleType = RoleType.User},

			};
		}

		public ObservableCollection<UserInfo> Users => _users;



	}
}
