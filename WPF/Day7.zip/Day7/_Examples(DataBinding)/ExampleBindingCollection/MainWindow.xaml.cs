﻿using ExampleBindingCollection.Model.Entities;
using ExampleBindingCollection.Model.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExampleBindingCollection
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private BookRepository bookRepository;
		public MainWindow()
		{
			InitializeComponent();
			bookRepository=new BookRepository();
			this.Loaded += MainWindow_Loaded;
		}

		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			// привязка в коде 
			//dgBooks.ItemsSource = bookRepository.Books;
		}

		private void btnShowState_Click(object sender, RoutedEventArgs e)
		{
			// получение данных из таблицы
			//List<Book> books = ((IEnumerable<Book>)dgBooks.ItemsSource).ToList();
			MessageBox.Show("Count: " + bookRepository.CountBooks.ToString());
		}

		private void btnEditObject_Click(object sender, RoutedEventArgs e)
		{
			// добавление нового элемента в коде 
			var book = new Book()
			{
				Price = 333,
				Title = "ASP.NET"
			};

			bookRepository.AddBook(book);

		}
	}
}
