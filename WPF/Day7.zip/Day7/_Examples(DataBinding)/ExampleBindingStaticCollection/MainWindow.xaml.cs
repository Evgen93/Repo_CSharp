﻿using ExampleBindingCollection.Model.Entities;
using ExampleBindingCollection.Model.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExampleBindingCollection
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			this.Loaded += MainWindow_Loaded;
		}

		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			// привязка в коде 
			//dgBooks.ItemsSource = BookRepository.Books;
		}

		private void btnShowState_Click(object sender, RoutedEventArgs e)
		{
			// получение данных из таблицы
			//List<Book> books = ((IEnumerable<Book>)dgBooks.ItemsSource).ToList();
			MessageBox.Show("Count: " + BookRepository.CountBooks.ToString());
		}

		private void btnEditObject_Click(object sender, RoutedEventArgs e)
		{
			// добавление нового элемента в коде 
			var book = new Book()
			{
				Price = 333,
				Title = "ASP.NET"
			};

			BookRepository.AddBook(book);

			// переход в таблице на добавленный элемент 
			dgBooks.ScrollIntoView(book);
		}
	}
}
