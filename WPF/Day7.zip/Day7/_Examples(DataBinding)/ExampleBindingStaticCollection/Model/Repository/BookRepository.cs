﻿using ExampleBindingCollection.Model.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleBindingCollection.Model.Repository
{
	public static class BookRepository
	{

		//  использование ObservableCollection обеспечивание обновление привязки 
		// при изменении содержания коллекции (добавление/удаление элементов)
		private static ObservableCollection<Book> books;

		static BookRepository()
		{
			books = new ObservableCollection<Book>()
										{
												new Book(){Title="C#", Price=150, IsElDoc=true},
												 new Book(){Title="WPF", Price=500, IsElDoc=false},
													new Book(){Title="ASP.NET", Price=780, IsElDoc=false},
										};
		}

		public static int CountBooks
		{
			get { return books.Count; }
		}
		public static ObservableCollection<Book> Books
		{
			get
			{
				return books;
			}
		}

		public static void AddBook(Book newBook)
		{
			if (newBook == null)
				throw new ArgumentNullException("newBook is NULL");
			books.Add(newBook);
		}

	}
}
