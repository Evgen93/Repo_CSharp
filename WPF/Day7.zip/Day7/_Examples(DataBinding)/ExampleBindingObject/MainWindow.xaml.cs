﻿using ExampleBindingObject.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExampleBindingObject
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			this.Loaded += MainWindow_Loaded;
		}

		void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			// Привязка в коде 

			// Создание объекта Book в коде
			// Book book=new Book()
			// {
			//    Title="Richter CLR via C#",
			//    Price=60.00m,
			//    IsElDoc=true
			// };

			// установка DataContext для Window 
			// this.DataContext = book;

			// установка DataContext для Grid
			// grdMain.DataContext = book;
		}

		private void btnShowState_Click(object sender, RoutedEventArgs e)
		{
			// Вывод состояния объекта 
			var book = grdMain.DataContext as Book;
			MessageBox.Show(book?.ToString());
		}

		private void btnEditObject_Click(object sender, RoutedEventArgs e)
		{
			// Изменение значений свойств объекта в коде
			// для демонстрации работы INotifyPropertyChanged

			var book = grdMain.DataContext as Book;
			if (book != null)
			{
				book.Price = 333;
				book.Title = "ASP.NET ";
			}


		}

	}
}
