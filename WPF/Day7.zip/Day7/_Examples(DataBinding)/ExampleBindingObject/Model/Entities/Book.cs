﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ExampleBindingObject.Model.Entities
{
    // уведомление элемента управления об изменении свойства в коде
    // необходимо для окна реализовать интерфейс INotifyPropertyChanged
    public class Book : INotifyPropertyChanged
    {
        private string title;
        public string Title
        {
            get { return title; }
            set
            {
                if (String.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Title  Is Null or WhiteSpace ");
                title = value;
                OnPropertyChanged();
				
							// или использование 
	            // OnPropertyChanged(nameof(Title));
			}
        }


        private decimal price;
        public decimal Price
        {
            get { return price; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Price< 0");
                price = value;
                OnPropertyChanged();
            }
        }


        private bool isElDoc;
        public bool IsElDoc
        {
            get { return isElDoc; }
            set { isElDoc = value; }
        }


        // интерфейс INotifyPropertyChanged предоставляет событие
        // PropertyChanged, которое обеспечивает передачу информации элементу 
        // управления при изменении значения свойства в коде
        public event PropertyChangedEventHandler PropertyChanged;

        // метод, вызывающий событие об изменении свойства
        // в данный метод передаем имя изененнного свойства 
        // для уведомления привязки данных 
        protected virtual void OnPropertyChanged([CallerMemberName] string PropertyName = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
        }

        public override string ToString()
        {
            return String.Format("Title: {0}, Price: {1:N2},  {2}", title, price, isElDoc);
        }
    }
}
