﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Example3BindingDictionary.Model.Entities
{
    public class Book : INotifyPropertyChanged
    {
        private string title;
        public string Title
        {
            get { return title; }
            set
            {
                if (String.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Title  Is Null or WhiteSpace ");
                title = value;
                OnPropertyChanged();
            }
        }


        private decimal price;
        public decimal Price
        {
            get { return price; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("Price< 0");
                price = value;
                OnPropertyChanged();
            }
        }


        private bool isElDoc;
        public bool IsElDoc
        {
            get { return isElDoc; }
            set { isElDoc = value; }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string PropertyName = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
        }

        public override string ToString()
        {
            return String.Format("Title: {0}, Price: {1:N2},  {2}", title, price, isElDoc);
        }
    }
}
