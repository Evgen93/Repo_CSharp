﻿using Example3BindingDictionary.Model.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example3BindingDictionary.Model.Repository
{
    public static class BookRepository
    {

        private static Dictionary<string, Book> books;

        static BookRepository()
        {
            books = new Dictionary<string, Book>();
            books.Add("978-5-01-000123-1", new Book() { Title = "C#", Price = 128.00m, IsElDoc = false });
            books.Add("978-5-01-784596-2", new Book() { Title = "WPF", Price = 500.50m,  IsElDoc = false });
            books.Add("978-5-01-122322-1", new Book() { Title = "ASP.NET", Price = 780.40m, IsElDoc = false });      
        }

        public static int CountBooks
        {
            get { return books.Count; }
        }
        public static Dictionary<string,Book> Books
        {
            get
            {  return books;
            }
        }

        public static void AddBook(string ISBN, Book newBook)
        {
            if (newBook == null)
                throw new ArgumentNullException("newBook is NULL");
            books.Add(ISBN, newBook);
        }

    }
}
