﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFMediaPlayer.Entities
{
    public class VideoInfo
    {
        public Uri FilePath { get; set; }

        public String FileName { get; set; }

        public VideoInfo(string filePath, string fileName)
        {
            if (filePath == String.Empty && fileName == String.Empty)
            {
                throw new ArgumentNullException();
            }
            FilePath = new Uri(filePath);
            FileName = fileName;
        }

        public VideoInfo(Uri filePath, string fileName)
        {
            if (filePath != null && fileName != String.Empty)
            {
                throw new ArgumentNullException();
            }
            FilePath = filePath;
            FileName = fileName;
        }

        public override string ToString()
        {
            return FileName;
        }
    }
}
