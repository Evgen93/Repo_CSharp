﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace WPFMediaPlayer.Entities.Conventers
{
    public class VideoPositionConventer : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null)
            {
                TimeSpan ts = (TimeSpan)value;
                return (double)ts.Seconds;
            }
            return -1.0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null)
            {
                double val = (double)value;
                return TimeSpan.FromSeconds(val);
            }
            return new TimeSpan(0, 0, 0);
        }
    }
}
