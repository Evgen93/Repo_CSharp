﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WPFMediaPlayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool pauseVideo;
        private BindingList<Uri> videoList;
        private bool slideHasChanged;

        public MainWindow()
        {
            InitializeComponent();
            pauseVideo = true;
            videoList = new BindingList<Uri>();
            lbPlayList.ItemsSource = videoList;
            slideHasChanged = false;
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0,0,0,0,1);
            timer.Tick += Timer_Tick;
            timer.Start();

            player.Volume = 0.5;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (slideHasChanged && Mouse.LeftButton == MouseButtonState.Released)
            {
                player.Position = TimeSpan.FromSeconds(slVideoRewind.Value);
                slideHasChanged = false;
            }
        }

        private void Window_MouseEnter(object sender, MouseEventArgs e)
        {
            gridControlPlayer.Visibility = Visibility.Visible;
            mnuOpenFile.Visibility = Visibility.Visible;
            expMonieList.Visibility = Visibility.Visible;
        }

        private void Window_MouseLeave(object sender, MouseEventArgs e)
        {
            gridControlPlayer.Visibility = Visibility.Hidden;
            mnuOpenFile.Visibility = Visibility.Hidden;
            expMonieList.Visibility = Visibility.Hidden;
            expMonieList.IsExpanded = false;
        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            if (player.Source != null)
            {
                if (pauseVideo)
                {
                    player.Play();
                    btnPlay.Content = "Pause";
                    pauseVideo = false;
                }
                else
                {
                    player.Pause();
                    btnPlay.Content = "Play";
                    pauseVideo = true;
                }
            }
            else if(videoList.Count != 0)
            {
                player.Source = videoList[0];
                player.Play();
                btnPlay.Content = "Pause";
                pauseVideo = false;
            }
        }

        private void slVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            player.Volume = slVolume.Value;
        }

        private void player_MediaOpened(object sender, RoutedEventArgs e)
        {
            slVideoRewind.Maximum = player.NaturalDuration.TimeSpan.TotalSeconds;
        }

        private void slVideoRewind_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            slideHasChanged = true;
        }

        private void File_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            if (opf.ShowDialog().Value)
            {
                Uri uri = new Uri(opf.FileName);
                foreach (var item in videoList)
                {
                    if (item == uri)
                    {
                        return;
                    }
                }
                videoList.Add(uri);
            }
        }

        private void lbPlayList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var lb = (ListBox)sender;
            player.Source = (Uri)lb.SelectedItem;
            player.Play();

            if ((string)btnPlay.Content != "Pause")
            {
                btnPlay.Content = "Pause";
            }
        }

        private void last_Click(object sender, RoutedEventArgs e)
        {
            int currentIndex = GetIndexCurrentVideo();
            if (currentIndex > 1)
            {
                player.Source = videoList[currentIndex - 1];
                player.Play();
                btnPlay.Content = "Pause";
            }
            else
            {
                player.Source = videoList[videoList.Count - 1];
                player.Play();
                btnPlay.Content = "Pause";
            }
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            int currentIndex = GetIndexCurrentVideo();
            if (currentIndex < videoList.Count - 1)
            {
                player.Source = videoList[currentIndex + 1];
                player.Play();
                btnPlay.Content = "Pause";
            }
            else
            {
                player.Source = videoList[0];
                player.Play();
                btnPlay.Content = "Pause";
            }
        }

        private int GetIndexCurrentVideo()
        {
            Uri uri = player.Source;

            for (int i = 0; i < videoList.Count; i++)
            {
                if (videoList[i] == uri)
                {
                    return i;
                }
            }
            return -1;
        }
    }
}
