﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace Example9MarkupExtension.Extensions
{
	public class SelfBindingExtension : MarkupExtension
	{
		public string Path { get; set; }

		public IValueConverter Converter { get; set; }

		public SelfBindingExtension()
		{
			
		}

		public SelfBindingExtension(string path)
		{
			Path = path;
		}

		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			try
			{

				if (string.IsNullOrEmpty(Path))
					throw new ArgumentNullException("Path", "The Path can not be null");

				//Получим провайдер, с информацией об объектре и првязках
				var providerValuetarget = (IProvideValueTarget)serviceProvider.GetService(typeof(IProvideValueTarget));

				//Получим объект, вызвавший привязку
				FrameworkElement targetObject = (FrameworkElement)providerValuetarget.TargetObject;

				//Получим свойство для возращения значения привязки
				PropertyInfo sourceProperty = targetObject.GetType().GetProperty(Path);

				//получим значение свойства
				object value = sourceProperty?.GetValue(targetObject, null);

				//Получим свойство, которое следует изменять
				DependencyProperty dependencyProperty = (DependencyProperty)providerValuetarget.TargetProperty;
			
				//Если у нас задан конвертер, прогоним значение через него
				if (Converter != null)
					return Converter.Convert(value, dependencyProperty.PropertyType, null, Thread.CurrentThread.CurrentCulture);
				else
					return value;
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex);
				return null;
			}
		}
	}
}
