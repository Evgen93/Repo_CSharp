﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;

namespace Example9MarkupExtension.Extensions
{
	public class MaxValueExtension : MarkupExtension
	{
		public object Value1 { get; set; }
		public object Value2 { get; set; }

		public MaxValueExtension()
		{
			
		}

		public MaxValueExtension(object value1, object value2)
		{
			Value1 = value1;
			Value2 = value2;
		}
		public override object ProvideValue(IServiceProvider serviceProvider)
		{

			IProvideValueTarget provideValueTarget = (IProvideValueTarget) serviceProvider.GetService(typeof(IProvideValueTarget));
			
			object val = GetMaxValue();

			if (provideValueTarget.TargetProperty is DependencyProperty dependencyProperty)
			{
				if (val is IConvertible)
				{
					val = Convert.ChangeType(val, dependencyProperty.PropertyType);
				}
			}
			else
			{
				if (provideValueTarget.TargetProperty is PropertyInfo propertyInfo)
				{
					if (val is IConvertible)
					{
						val = Convert.ChangeType(val, propertyInfo.PropertyType);
					}
				}
			}

			return val;
		}

		private object GetMaxValue()
		{
			if (Value1 is IComparable compare && Value2 is IComparable)
			{
				if (compare.CompareTo(Value2) >= 0)
					return Value1;
				return Value2;
			}
			else
			{
				return Value1;
			}
		}
	}
}
