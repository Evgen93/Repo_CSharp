﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;

namespace Example9MarkupExtension.Extensions
{
	public class IndexConverter : MarkupExtension, IValueConverter
	{
		public override object ProvideValue(IServiceProvider serviceProvider)
		{
			return this;
		}

		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return "Index:" + ": " + value;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
